local regions = {}
local colors = {}
colors.g = {153,169,128}
colors.c = {130,110,100}
colors.s = {229,211,168}
colors.p = {220,220,220}
colors.w = {174,145,115}
colors.l = {173,64,51}



function love.load()
	print(love.getVersion())
	love.filesystem.setIdentity("minimap")
	local first = true
	local regionName, x, y, w
	local region

	local drawX = 0
	local drawY = 0
	for line in love.filesystem.lines("VolcanoIsland.txt") do
		if first then
			first = false

			regionName, x, y, w = string.match(line, "(%w+)%s(%S+)%s(%S+)%s(%S+)")
			region = newRegion(regionName, x, y, w)
		else
			drawX = 0
			drawY = drawY + 1
			region.data[drawY] = {}
			for char in string.gmatch(line, "%w") do
				drawX = drawX + 1
				region.data[drawY][drawX] = char
			end
		end
	end
	region:render()
	region:encode()
end


function newRegion(regionName, x, y, w)
	print(regionName, x, y, w)
	local r = {}
	r.name = regionName
	r.x = tonumber(x)
	r.y = tonumber(y)
	r.w = tonumber(w)
	r.h = tonumber(w)
	r.data = {}
	r.canvas = love.graphics.newCanvas(r.w/4, r.h/4)

	function r:render()
		love.graphics.setCanvas(self.canvas)
		for y, row in pairs(self.data) do
			for x, char in pairs(row) do
				if colors[char] then
					love.graphics.setColor(unpack(colors[char]))
					love.graphics.rectangle("fill",x*2,y*2,2,2)
				end
			end
		end
		love.graphics.setCanvas()
	end


	function r:encode()
		self.canvas:newImageData():encode("png", regionName..".png")
	end

	table.insert(regions, r)
	
	return r
end

function love.draw()
	love.graphics.clear(128,145,168)
	love.graphics.setCanvas()
	love.graphics.setColor(255,255,255, 255)
	love.graphics.setBlendMode("alpha","premultiplied")
	love.graphics.draw(regions[1].canvas,400,300,0,1,1, regions[1].w/8, regions[1].h/8)
	love.graphics.setBlendMode("alpha")
	print(love.graphics.getColor())
	love.graphics.circle("line",400,300,regions[1].w/8)
end